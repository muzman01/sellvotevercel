export const tokens = [
  "0xed24fc36d5ee211ea25a80239fb8c4cfd80f12ee", // TESTNET BUSD
];

export const realTokenList = [
  "0xdac17f958d2ee523a2206206994597c13d831ec7", // USDT
  "0xb8c77482e45f1f44de1745f52c74426c631bdd52", // BNB
  "0x4fabb145d64652a948d72533023f6e7a623c7c53", // BUSD
];
