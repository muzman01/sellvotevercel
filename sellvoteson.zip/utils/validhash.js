const validhash = (walletAdress, transicaitonHash) => {
  if (!transicaitonHash) return "Boş alanlar var lütfen doldur";
};

export default validhash;
