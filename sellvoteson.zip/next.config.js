module.exports = {
  env: {
    BASE_URL: "http://localhost:3000",
    MONGODB_URL:
      "mongodb+srv://blokfieldsellvote:Gerok261.@cluster0.xqejn.mongodb.net/myFirstDatabase?retryWrites=true&w=majority",
  },
};
