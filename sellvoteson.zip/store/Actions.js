const ACTIONS ={
    NOTIFY:'NOTIFY',
    AUTH:'AUTH'
}

export default ACTIONS